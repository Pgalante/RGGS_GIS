﻿Treelopi ReadMe   
16 November, 2019


This compressed folder contains the following information for a spatial analysis of an imaginary species in New York State - Treelopi


1. TreelopiSightings.csv [Treelopi occurrences generated for New York State]
2. Landcover (i.e., lulc250k.shp). These data come from the Cornell University Geographic Information Repository (CUGIR) and represents land cover data from New York State and portions of surroundings states in 1990. 
3. USA_states (i.e., USA.shp). These data come from naturalearthdata.org, a free GIS repository: (https://www.naturalearthdata.com/http//www.naturalearthdata.com/download/10m/cultural/ne_10m_admin_1_states_provinces.zip)
4. Roads (i.e., ne_10m_roads.shp). These data come from naturalearthdata.org, a free GIS repository: (https://www.naturalearthdata.com/http//www.naturalearthdata.com/download/10m/cultural/ne_10m_roads.zip)
5. NY_regional_bio_1.tif is a current bioclimatic layer downloaded from worldclim.org/version2 at 30 arc-second resolution and cropped to a bounding box around New York State and the northeastern United States.


For more information on these files, refer to Table 1 (and the links therein) in “Modeling Suitable Habitat for a Species of Conservation Concern: An Introduction to Spatial Analysis with QGIS” exercise available at https://ncep.amnh.org.